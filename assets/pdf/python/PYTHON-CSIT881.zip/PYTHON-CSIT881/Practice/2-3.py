input_string = input("Enter a string: ")
choice = input("Uppercase or Lowercase? (U/L): ")

if choice == "U" or choice == "u":
    print("The Uppercase of {0} is {1}.".format(input_string, input_string.upper()))
elif choice == "L" or choice == "l":
    print("The Lowercase of {0} is {1}.".format(input_string, input_string.lower()))
else:
    print("Invalid input.")