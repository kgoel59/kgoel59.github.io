id = int(input("Enter a student id: "))
start_num = int(input("Enter a starting number: "))
equations = int(input("Enter number of equations: "))
print("Equation display:")

for i in range(0,equations):
    print(f"{id} + {start_num + i} = {id + start_num + i}")
