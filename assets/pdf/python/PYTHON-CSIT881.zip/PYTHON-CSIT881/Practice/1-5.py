print("Laptop rental calculation")
brand = input("Enter the laptop brand: ")
app_cost = int(input("Enter the application cost: "))
month_cost = int(input("Enter the monthly cost: "))
months = int(input("Enter the number of months: "))

rental_cost = month_cost * months
total_cost = app_cost + rental_cost

print("Rental cost for {0} laptop".format(brand))
print("Application cost: ${0}".format(app_cost))
print("Rental cost: ${0} x {1} month = ${2}".format(month_cost,months,rental_cost))
print("Total cost: ${0} + ${1} = ${2}".format(app_cost,rental_cost,total_cost))