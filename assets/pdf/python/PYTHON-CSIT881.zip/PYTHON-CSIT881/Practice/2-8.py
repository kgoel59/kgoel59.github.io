n = int(input("Enter a positive integer: "))



for i in range(n):
    print('  '*(n-i-1), end='')
    pattern = []
    k = 1
    for j in range(1,2*(i+1)):
        pattern.append(k)
        if j >= i + 1:
            k -= 1
        else:
            k += 1
    print(' '.join(str(x) for x in pattern))