def selection_sort(arr):
    print(f"Selection Sort Algorithm for {arr}")

    n = len(arr)
    if n <= 1:
        return  
    
    for i in range(n-1):
        max_index = i
 
        for j in range(i + 1, n):
            # select the max element
            if arr[j] > arr[max_index]:
                max_index = j
         # swapping the elements to sort the arr
        (arr[i], arr[max_index]) = (arr[max_index], arr[i])

         #print the round
        print(f"After round {i}: {arr}")

arr = []

while(True):
    num = input("Enter an integer (or enter quit): ")
    if num == "quit":
        break
    arr.append(int(num))

selection_sort(arr)