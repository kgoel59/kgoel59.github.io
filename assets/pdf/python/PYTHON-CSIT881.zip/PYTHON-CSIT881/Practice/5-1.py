for i in range(0,10):
    print("{0:>2} + {1:>2} = {2:>2}".format(i+1,i+1,2*(i+1)))