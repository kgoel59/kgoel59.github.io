for i in range(1,10):
    str_pattern = ""
    for i in range(1,i+1):
        str_pattern += str(i)
    print(str_pattern)