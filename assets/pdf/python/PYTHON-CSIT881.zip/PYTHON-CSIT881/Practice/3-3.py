even_found = False
odd_found = False
even_number = 0
odd_number = 0

num = input("Enter an integer (or EXIT): ")
while(num != "EXIT"):
    num = int(num)
    if even_found is not True:
        if num%2 == 0:
            even_found = True
            even_number = num

    if odd_found is not True:
        if num%2 != 0:
            odd_found = True
            odd_number = num
    num = input("Enter an integer (or EXIT): ")

if even_found:
    print(f"First even number is {even_number}")
else:
    print("Even number not found")

if odd_found:
    print(f"First odd number is {odd_number}")
else:
    print("Odd number not found")