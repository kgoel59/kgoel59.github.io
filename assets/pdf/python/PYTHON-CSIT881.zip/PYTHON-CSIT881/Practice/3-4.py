lines = int(input("Enter number of lines: "))
line_num = int(input("Enter number of numbers on each line: "))

num = -1
for i in range(0,lines):
    num += 1
    for j in range(0,line_num-1):
        print(num,end=",")
        num += 1
    print(f"{num}.")