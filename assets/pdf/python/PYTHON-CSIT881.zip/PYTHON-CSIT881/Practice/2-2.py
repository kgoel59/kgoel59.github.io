degree = input("Which degree do you choose? Undergraduate (U) or Postgraduate (P): ")

if degree == "U":
  print()
  print("Course summary:")
  print("Location: Wollongong, Liverpool")
  print("Duration: 3 years full-time or part-time equivalent")
else:
  course = input("Which course do you choose? Master by Coursework (C) or Master by Research (R): ")

  if course == "C":
    print()
    print("Course summary:")
    print("Location: Wollongong, Liverpool")
    print("Duration: 1.5-2 years full-time or part-time equivalent")
  else:
    print()
    print("Course summary:")
    print("Location: Wollongong")
    print("Duration: 2 years full-time or part-time equivalent")
