zorg = int(input("Enter number of zrog: "))
zmu = int(input("Enter number of zmu: "))
zshark = int(input("Enter number of zhark: "))

zorg_legs = zorg * 2
zmu_legs = zmu * 5
zshark_legs = zshark * 10
total_legs = zorg_legs + zmu_legs + zshark_legs

print()
print("Leg calculation")
print("Zrog legs = {0} x 2 = {1}".format(zorg, zorg_legs))
print("Zmu legs = {0} x 5 = {1}".format(zmu, zmu_legs))
print("Zhark legs = {0} x 10 = {1}".format(zshark,zshark_legs ))
print("Total legs = {0} + {1} + {2} = {3}".format(zorg_legs,zmu_legs,zshark_legs,total_legs))