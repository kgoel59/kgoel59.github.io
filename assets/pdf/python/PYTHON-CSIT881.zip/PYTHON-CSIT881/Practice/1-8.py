from datetime import datetime

length_box = int(input("Enter length of the box: "))
dob_str = input("Enter your dob (DD-MM-YYYY): ")

dob = datetime.strptime(dob_str,'%d-%m-%Y')
dob_formatted = dob.strftime('%d/%b/%Y')

print('*'*length_box)
print('|DOB:{0:>{1}}|'.format(dob_formatted, length_box - 6))
print('*'*length_box)

# ********************
# |DOB:   01/Mar/2000|
# ********************
# 12345678901234567890