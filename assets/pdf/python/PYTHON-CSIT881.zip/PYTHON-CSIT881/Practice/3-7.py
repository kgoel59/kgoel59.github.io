base = input("Enter a word for base: ")
side = input("Enter a word for side: ")
print("Here is the pattern:")

print(f"*{base}*")
for i in side:
    print(i,end="")
    print(f"{i:>{len(base) + 1}}")
print(f"*{base}*")