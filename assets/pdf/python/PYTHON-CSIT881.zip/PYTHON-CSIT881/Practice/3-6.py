while(True):
    i = input("Enter an integer (or exit): ")

    if i == "exit":
        break

    i = int(i)

    if i > 0:
        print(f"Positive integer, display addition: {i} + {i} = {2*i}")
    elif i < 0:
        print(f"Negative integer, display multiplication: ({i}) x ({i}) = {i*i}")
    elif i == 0:
        print("Zero, display just zero: 0")