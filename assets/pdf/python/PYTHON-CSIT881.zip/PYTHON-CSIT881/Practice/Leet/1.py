def lengthOfLongestSubstring(s: str) -> int:
    max_sub_len = 0
    dict = {}
    for i in range(0,len(s)):
        sub_len = 0
        dict = {}
        for j in range(i,len(s)):
            if dict.get(s[j]) is not None:
                max_sub_len = max(sub_len,max_sub_len)
                break
            else:
                sub_len += 1
                dict[s[j]] = 1
        max_sub_len = max(sub_len, max_sub_len)
    return max_sub_len

print(lengthOfLongestSubstring(" "))