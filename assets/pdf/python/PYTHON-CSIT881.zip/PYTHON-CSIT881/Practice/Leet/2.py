def threeSum(nums):
    nums.sort()
    result = []
    for i in range(len(nums) - 1):
        j = i + 1
        sum_ij = nums[i] + nums[j]
        k = len(nums) - 1
        while(k>j):
            if(abs(sum_ij) > abs(nums[k])):
                break
            elif (abs(sum_ij) < abs(nums[k])):
                k -= 1
            else:
                result.append([nums[i],nums[j],nums[k]])
                break
    return result


threeSum([0,1,1])