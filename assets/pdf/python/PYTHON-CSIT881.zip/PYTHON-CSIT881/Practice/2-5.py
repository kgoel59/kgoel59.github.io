
int_a = int(input("Enter an integer: "))
int_b = int(input("Enter another integer: "))

min_int = min(int_a,int_b)
max_int = max(int_a,int_b)

for i in range(min_int, max_int+1):
    print("{0:>5} + {1:>5} = {2:>5}".format(i,i,2*i))
