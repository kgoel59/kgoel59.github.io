word = input("Enter a string: ")
count = int(input("Enter a positive integer: "))
print("Display pattern:")

for ch in word:
    for j in range(0,count):
        print(ch,end="")
    print()