subject_choice = input("Which subject did you enroll in? (a) CSIT110 (b) CSIT881: ")

if subject_choice == "a":
    print("You are an undergraduate.")
elif subject_choice == "b":
    print("You are a postgraduate.")
else:
    print("Invalid input.")