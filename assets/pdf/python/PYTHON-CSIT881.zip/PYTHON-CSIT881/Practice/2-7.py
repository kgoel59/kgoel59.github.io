input_string = input("Enter some characters: ")
char_count = int(input("Enter the number of characters to be displayed: "))

range_len = min(char_count, len(input_string))
for i in range(0, range_len):
    if i == range_len - 1:
        print(input_string[i])
    else:
        print(f"{input_string[i]}-",end="")
