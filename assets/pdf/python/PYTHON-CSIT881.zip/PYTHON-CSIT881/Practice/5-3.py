for i in range(0,10):
    if (i+1) == 10:
        print("{0}".format(i+1))
    else:
        print("{0}".format(i+1),end=" : ")