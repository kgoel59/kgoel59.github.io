total_subject = int(input("How many subjects would you choose for this session: "))

subject_count = total_subject
while subject_count > 0:
    input_break = input("Would you like to continue subject enrolment? (Y/N): ")
    if input_break != "Y":
        break
    
    subject_name = input("Which subject would you like: ")
    print("You have successfully enrolled in {}.".format(subject_name))

    subject_count -= 1

if subject_count == 0:
    print(f"You have finished the enrollment of all {total_subject} subjects.")
elif subject_count == 1:
    print(f"You have not completely finished the enrollment. There is 1 subject to be enrolled.")
else:
    print(f"You have not completely finished the enrollment. There are {subject_count} subjects to be enrolled.")