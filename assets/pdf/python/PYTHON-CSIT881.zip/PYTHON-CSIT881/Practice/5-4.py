for i in range(1,6):
    if 2*i == 10:
        print("{}.".format(2*i))
    else:
        print(2*i, end=", ")