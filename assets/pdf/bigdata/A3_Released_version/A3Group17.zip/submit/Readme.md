Code is in main.py
Classifiers are classifier folder

Add ipynb file for verifying the output