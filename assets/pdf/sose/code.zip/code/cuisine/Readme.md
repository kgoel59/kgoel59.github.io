## Prerequisites

Make sure you have the following installed:

- [Java Development Kit (JDK)](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html) (version 11 or higher)
- [Apache Maven](https://maven.apache.org/download.cgi)

## Build the Project

To build the project, navigate to the project root directory and run the following command:

```bash
mvn clean install
```

- `mvn clean` removes any previously compiled files to ensure a fresh build.
- `mvn install` compiles the code, runs tests, and packages the application into a JAR file.

## Run the Application

After a successful build, you can run the application with the following command:

```bash
java -jar target/*.jar
```

This command will execute the JAR file located in the `target` directory. If there are multiple JAR files, you may need to specify the exact JAR file name.