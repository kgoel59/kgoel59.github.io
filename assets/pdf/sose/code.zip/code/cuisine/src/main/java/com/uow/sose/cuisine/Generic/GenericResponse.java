package com.uow.sose.cuisine.Generic;

import lombok.Data;

@Data
public class GenericResponse {
    private String message;
    private int statusCode;
}
