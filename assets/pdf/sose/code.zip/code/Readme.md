### Service Details

The services can be accessed via the following URLs:

- [Air Service](https://csci927-lam001-804675582257.us-central1.run.app)
- [Swagger UI](https://ltempurl.com)
- [Cuisines Service](https://cusines-804675582257.us-central1.run.app)
- [Accommodation Service](https://accomodation-804675582257.us-central1.run.app)

For deployment instructions or if any of the URLs are unavailable, please refer to the provided README file in each service.