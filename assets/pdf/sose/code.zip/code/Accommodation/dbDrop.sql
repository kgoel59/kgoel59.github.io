-- Drop all tables
DROP TABLE IF EXISTS Feedback;
DROP TABLE IF EXISTS RoomBooking;
DROP TABLE IF EXISTS CulturalExperience;
DROP TABLE IF EXISTS Guests;

-- Drop the database
DROP DATABASE IF EXISTS cultural_program;
