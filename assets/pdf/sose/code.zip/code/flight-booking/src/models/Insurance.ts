export interface Insurance {
  insurance_id: number;
  price: number;
  type: string;
}
