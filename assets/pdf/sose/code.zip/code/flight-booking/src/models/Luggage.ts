export interface Luggage {
  luggage_id: number;
  price: number;
  weight: number;
}
