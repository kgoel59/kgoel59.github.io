namespace SOSE_API.Utility
{
    public class SD
    {
        public const string Role_Admin = "admin";
        public const string Role_Customer = "customer";
    }
}
