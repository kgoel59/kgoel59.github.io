﻿namespace SOSE_API.Interface
{
    public interface IBookingRepository
    {
    }
}
