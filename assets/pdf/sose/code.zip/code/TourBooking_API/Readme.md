## Prerequisites

Ensure you have the following installed:

- [.NET SDK](https://dotnet.microsoft.com/download) (version 6.0 or higher)

## Build the Project

To build the project, open a terminal, navigate to the project root directory, and run:

```bash
dotnet build
```

- This command compiles the project and generates the necessary binaries. If the build is successful, you’ll see a message indicating that the build succeeded.

## Run the Application

Once the project is built successfully, you can run the application with the following command:

```bash
dotnet run
```
