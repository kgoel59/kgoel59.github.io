function main() {
    console.log("loaded")
}

function red() {
    console.log("red")
}

function blue() {
    console.log("blue")
}

function confirmBox() {
    test = confirm("Confirm Box")
    if(test) {
        alert("its ok")
    } else {
        alert("it's not")
    }
}

function promptBox() {
    prompt("Prompt Box","This is a test")
}