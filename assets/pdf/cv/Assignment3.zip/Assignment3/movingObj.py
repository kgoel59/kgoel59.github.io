'''7836685 kg956 CSCI935  Karan Goel Assignment 3'''

"""
SOLUTION FOR TASK2

tracking  and selection
1. Intialize two array current_boxes and prev_boxes
2. Store the bounding box of persons from the mobilnet cnn into var current_boxes
3. Check the number of bounding box and initialize array of labels of similar lenght
ex if there are two bounding boxes we will create an array of labels of lenght 2 and mark them as Person1 Person 2
4. Loop through current boxes
4. if prev_boxes are empty use the labels array to mark the frame
5. if prev_boxes are not empty loop through all prev boxes and calculate 
**Centeroid, Centeroid Distance and Size Ratio** with current box and select the best fit prev box
6. Update the label with best match prev box of the current box
7. Loop until all current boxes are marked
8. Set current boxes as prev boxes


Nearness to camera
1. Calculate area of each bounding box and set it into a new area array
2. Sort the array in reverse order
3. Select top 3 bounding box
4. Mark the boxes on frame

"""


import cv2
import sys
import numpy as np

#Task1
bg_subtractor = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=50, detectShadows=True)

#Task2
model = cv2.dnn.readNetFromTensorflow('frozen_inference_graph.pb',
                                      'ssd_mobilenet_v2_coco_2018_03_29.pbtxt.txt')

w,h = (300, 300)
object_id = 1
current_boxes = []
previous_boxes = []
labels = []
confidence_threshold = .5
dist_threshold = 10 
size_ratio_threshold = 1.2 

#To display the result
def stack_frame(frames):
    #Stack all frames for display
    a,b,c,d = frames
    display_frame = np.vstack([
        np.hstack([a, b]),
        np.hstack([c, d])
    ])

    return display_frame

#Tracking
def centroid(box):
    '''Compute the center (centroid) of a box'''
    return ((box[0] + box[2]) // 2, (box[1] + box[3]) // 2)

#Tracking
def centroid_distance(boxA, boxB):
    '''Compute the Euclidean distance between the centroids of two boxes'''
    cA = centroid(boxA)
    cB = centroid(boxB)
    return np.sqrt((cA[0] - cB[0])**2 + (cA[1] - cB[1])**2)

#Tracking
def size_ratio(boxA, boxB):
    '''Compute the size ratio of two boxes'''
    areaA = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
    areaB = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])
    return areaA / areaB

#NearToCamera
def box_area(box):
    '''Compute the area of a box'''
    return (box[2] - box[0]) * (box[3] - box[1])

#Task2
def detect_object_cnn(frame,output,id):
    detect_object_frame = frame.copy()

    global current_boxes

    current_boxes.clear()

    for detection in output[0, 0, :, :]:
        confidence = detection[2]
        class_id = detection[1]
        if confidence > confidence_threshold and class_id == id:
            box_x = detection[3] * w
            box_y = detection[4] * h
            box_width = detection[5] * w
            box_height = detection[6] * h
            current_boxes.append([int(box_x), int(box_y), int(box_width), int(box_height)])
            cv2.rectangle(detect_object_frame, (int(box_x), int(box_y)), (int(box_width), int(box_height)), (0, 0, 210), thickness=1)

    return detect_object_frame

#Task2
def track_object_cnn(frame):
    track_object_frame = frame.copy()
    
    global previous_boxes
    global current_boxes
    global labels

    new_labels = [-1] * len(current_boxes)

    if len(labels) < len(new_labels):
        labels.extend([-1] * len(new_labels))
    
    for k in range(0, len(labels)):
        if labels[k] == -1:
          labels[k] = "Person " + str(k+1)

    for i, box in enumerate(current_boxes):
        best_label = -1
        for j, prev_box in enumerate(previous_boxes):
            distance = centroid_distance(box, prev_box)
            ratio = size_ratio(box, prev_box)

            if distance < dist_threshold and ratio < size_ratio_threshold and labels[j] != -1:
                best_label = labels[j]
                labels[j] = -1
    
        new_labels[i] = best_label

    for i, box in enumerate(current_boxes):
        startX, startY, endX, endY = box
        cv2.rectangle(track_object_frame, (startX, startY), (endX, endY), (23, 230, 210), thickness=1)
        cv2.putText(track_object_frame, str(new_labels[i]), (startX, startY-10), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 255, 0), 2)

    previous_boxes = current_boxes
    labels = new_labels

    return track_object_frame

#Task2
def nearest_object_cnn(frame):
    global current_boxes
    if len(current_boxes) == 0:
        return frame

    # Sort the boxes based on area (largest to smallest) and pick top 3
    sorted_boxes = sorted(current_boxes, key=lambda x: box_area(x), reverse=True)[:2]

    nearest_object_frame = frame.copy()
    for box in sorted_boxes:
        startX, startY, endX, endY = box
        cv2.rectangle(nearest_object_frame, (startX, startY), (endX, endY), (255, 0, 0), thickness=2)

    return nearest_object_frame

#Task1
def detect_object_gaussian(frame):
    fgmask = bg_subtractor.apply(frame,  learningRate=-1)
    bg_only = bg_subtractor.getBackgroundImage()
    

    # Detect moving pixels using Gaussian Mixture background modelling
    fgmask_raw = fgmask.copy()  # Before noise removal

    # Remove noise using morphological operators
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_CLOSE, kernel)
    fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)

    # Connected component analysis
    ret, labels = cv2.connectedComponents(fgmask)

    # Output buffer for detected objects
    detected = np.zeros_like(frame)

    # Classify each object and count them
    person_count, car_count, other_count = 0, 0, 0
    for label in range(1, ret):
        component = (labels == label).astype(np.uint8) * 255
        contours, _ = cv2.findContours(component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w) / h
            if 0.3 < aspect_ratio < 0.7:
                person_count += 1
            elif aspect_ratio > 1.5:
                car_count += 1
            else:
                other_count += 1
            detected[y:y+h, x:x+w] = frame[y:y+h, x:x+w]

    total_objects = person_count + car_count + other_count
    fgmask_raw = cv2.cvtColor(fgmask_raw, cv2.COLOR_GRAY2BGR)

    return ([total_objects,person_count,car_count,other_count],bg_only,fgmask_raw,detected)

def main(*args):
    """
    Main execution function.
    """

    flag = args[0]
    path = args[1]

    #capture video
    vid = cv2.VideoCapture(path)

    # Check if the video file opened successfully
    if not vid.isOpened():
     print("Error: Couldn't open the video.")
     exit()

    width = int(vid.get(3))
    height = int(vid.get(4))
    scale = 640.0 / width
    vid.set(3, 640)
    vid.set(4, int(height * scale))

    frame_count = 0

    while vid.isOpened():
        ret, frame = vid.read()
        if not ret:
            break
        frame_count += 1

        #Task 1
        if flag == '-b':
          [total_objects,person_count,car_count,other_count],bg_only,fgmask_raw,detected = detect_object_gaussian(frame)
          print(f"Frame {frame_count:04d}: {total_objects} objects ({person_count} persons, {car_count} cars and {other_count} others)")
          cv2.imshow('Task1', stack_frame((frame,bg_only,fgmask_raw,detected)))
          if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        #Task 2
        elif flag == '-d':
          resized_frame = cv2.resize(frame, (w,h))
          model.setInput(cv2.dnn.blobFromImage(frame, size=(w, h), swapRB=True))
          output = model.forward()

          detect_person_frame = detect_object_cnn(resized_frame,output,id=object_id)
          track_person_frame = track_object_cnn(resized_frame)
          nearest_person_frame = nearest_object_cnn(resized_frame)
          cv2.imshow('Task2', stack_frame((resized_frame,detect_person_frame,track_person_frame,nearest_person_frame)))
          if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        else:
          print("flag unspecified")
          break

    vid.release()
    cv2.destroyAllWindows()


# get args from user
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Insufficient arguments provided.")
        exit(0)

    main(*sys.argv[1:])