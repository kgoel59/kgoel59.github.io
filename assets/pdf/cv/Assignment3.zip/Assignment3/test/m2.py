import cv2
import dlib
import numpy as np

# Load the DNN model
net = cv2.dnn.readNetFromTensorflow('frozen_inference_graph.pb', 'ssd_mobilenet_v2_coco_2018_03_29.pbtxt.txt')

# Load the class names
with open('object_detection_classes_coco.txt', 'r') as f:
    classes = f.read().strip().split('\n')

# Initialize tracker lists
trackers = []
labels = []

cap = cv2.VideoCapture('TownCentreXVID.avi')

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    h, w = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, scalefactor=1.0, size=(300, 300), mean=(127.5, 127.5, 127.5), swapRB=True, crop=False)
    net.setInput(blob)
    detections = net.forward()
    
    rects = []
    for i in range(detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > 0.5 and classes[int(detections[0, 0, i, 1])] == "person":
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            rects.append(box.astype("int"))

    # Use dlib's correlation tracker
    new_trackers = []
    new_labels = []
    for rect in rects:
        (startX, startY, endX, endY) = rect
        t = dlib.correlation_tracker()
        r = dlib.rectangle(startX, startY, endX, endY)
        t.start_track(frame, r)
        new_trackers.append(t)

        # Match new tracker with existing tracker
        for i, tracker in enumerate(trackers):
            pos = tracker.get_position()
            startX_t = int(pos.left())
            startY_t = int(pos.top())
            endX_t = int(pos.right())
            endY_t = int(pos.bottom())
            
            # Calculate centroid of existing and new bounding box
            cX_t = int((startX_t + endX_t) / 2.0)
            cY_t = int((startY_t + endY_t) / 2.0)
            cX_n = int((startX + endX) / 2.0)
            cY_n = int((startY + endY) / 2.0)

            distance = np.sqrt((cX_t - cX_n)**2 + (cY_t - cY_n)**2)
            
            if distance < 50:
                new_labels.append(labels[i])
                break
        else:
            new_labels.append(max(labels, default=0) + 1)

    trackers = new_trackers
    labels = new_labels

    for i, tracker in enumerate(trackers):
        pos = tracker.get_position()
        startX = int(pos.left())
        startY = int(pos.top())
        endX = int(pos.right())
        endY = int(pos.bottom())
        cv2.rectangle(frame, (startX, startY), (endX, endY), (0, 255, 0), 2)
        cv2.putText(frame, str(labels[i]), (startX, startY-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Select up to 3 pedestrians that are most close to the camera based on bounding box area
    if len(trackers) > 3:
        sizes = [(endX - startX) * (endY - startY) for tracker in trackers for pos in [tracker.get_position()]]
        largest_indices = sorted(range(len(sizes)), key=lambda i: sizes[i], reverse=True)[:3]
        trackers = [trackers[i] for i in largest_indices]
        labels = [labels[i] for i in largest_indices]

    cv2.imshow("Frame", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
