import cv2
import numpy as np

# Load the pre-trained MobileNet SSD model
modelConfiguration = "ssd_mobilenet_v2_coco_2018_03_29.pbtxt.txt"
modelWeights = "frozen_inference_graph.pb"
net = cv2.dnn.readNetFromTensorflow(modelWeights, modelConfiguration)

# Load the names of object classes in MS COCO
classesFile = "object_detection_classes_coco.txt"
classes = None
with open(classesFile, 'rt') as f:
    classes = f.read().rstrip('\n').split('\n')

# Set the input image size for the model
inputSize = 300

# Set the confidence threshold for detecting objects
confidenceThreshold = 0.5

# Set the maximum number of pedestrians to track and display
maxPedestrians = 3

# Initialize variables for tracking pedestrians
pedestrianIds = []
pedestrianBoxes = []

# Load a video and get its dimensions
videoPath = "path/to/video.mp4"
cap = cv2.VideoCapture(videoPath)
videoWidth = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
videoHeight = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Loop over all frames in the video
while True:
    # Read a frame from the video
    ret, frame = cap.read()
    if not ret:
        break

    # Create a blob from the input image and set it as input to the model
    blob = cv2.dnn.blobFromImage(frame, size=(inputSize, inputSize), swapRB=True, crop=False)
    net.setInput(blob)

    # Run forward pass through the model to detect objects in the image
    detections = net.forward()

    # Loop over all detected objects and filter out pedestrians
    for i in range(detections.shape[2]):
        classId = int(detections[0, 0, i, 1])
        if classes[classId] != 'person':
            continue

        confidence = detections[0, 0, i, 2]
        if confidence > confidenceThreshold:
            # Get the bounding box coordinates of the pedestrian
            x1 = int(detections[0, 0, i, 3] * videoWidth)
            y1 = int(detections[0, 0, i, 4] * videoHeight)
            x2 = int(detections[0, 0, i, 5] * videoWidth)
            y2 = int(detections[0, 0, i, 6] * videoHeight)

            # Add pedestrian ID and bounding box coordinates to lists
            pedestrianIds.append(i)
            pedestrianBoxes.append([x1, y1, x2 - x1, y2 - y1])

    # Track and display up to maxPedestrians pedestrians that are most close in space to the camera
    while len(pedestrianIds) > 0:
        # Select pedestrian with smallest bounding box area as closest to camera
        closestPedestrianIndex = np.argmin([box[2] * box[3] for box in pedestrianBoxes])
        closestPedestrianId = pedestrianIds[closestPedestrianIndex]
        closestPedestrianBox = pedestrianBoxes.pop(closestPedestrianIndex)
        pedestrianIds.remove(closestPedestrianId)

        # Draw bounding box around closest pedestrian on original image
        x1, y1, w, h = closestPedestrianBox
        cv2.rectangle(frame, (x1, y1), (x1 + w, y1 + h), (0, 255, 0), thickness=2)

        # Display label for closest pedestrian on original image
        label = str(closestPedestrianId + 1)
        labelSize, _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, fontScale=1.5, thickness=3)
        labelX1 = max(x1 - labelSize[0] // 2 - 5, 0)
        labelY1 = max(y1 - labelSize[1] - 5, 0)
        labelX2 = min(labelX1 + labelSize[0] + 10, videoWidth)
        labelY2 = min(labelY1 + labelSize[1] + 10, videoHeight)
        cv2.rectangle(frame, (labelX1 - 5, labelY1), (labelX2 + 5, labelY2), (255,