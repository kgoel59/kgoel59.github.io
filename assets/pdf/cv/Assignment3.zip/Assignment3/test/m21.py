import cv2
import numpy as np

def iou(boxA, boxB):
    '''Compute the intersection over union of two boxes'''
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    
    interArea = max(0, xB - xA) * max(0, yB - yA)
    boxAArea = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
    boxBArea = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])
    
    iou = interArea / float(boxAArea + boxBArea - interArea)
    
    return iou

# Load the DNN model
net = cv2.dnn.readNetFromTensorflow('frozen_inference_graph.pb', 'ssd_mobilenet_v2_coco_2018_03_29.pbtxt.txt')

# Load the class names
with open('object_detection_classes_coco.txt', 'r') as f:
    classes = f.read().strip().split('\n')

cap = cv2.VideoCapture('TownCentreXVID.avi')
previous_boxes = []
labels = []
nextLabel = 1

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    h, w = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, scalefactor=1.0, size=(300, 300), mean=(127.5, 127.5, 127.5), swapRB=True, crop=False)
    net.setInput(blob)
    detections = net.forward()
    
    current_boxes = []
    for i in range(detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > 0.5 and classes[int(detections[0, 0, i, 1])] == "person":
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            current_boxes.append(box.astype("int"))

    new_labels = [-1] * len(current_boxes)
    for i, box in enumerate(current_boxes):
        for j, prev_box in enumerate(previous_boxes):
            if iou(box, prev_box) > 0.5:
                new_labels[i] = labels[j]
                break
        if new_labels[i] == -1:
            new_labels[i] = nextLabel
            nextLabel += 1

    for i, box in enumerate(current_boxes):
        startX, startY, endX, endY = box
        cv2.rectangle(frame, (startX, startY), (endX, endY), (0, 255, 0), 2)
        cv2.putText(frame, str(new_labels[i]), (startX, startY-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    previous_boxes = current_boxes
    labels = new_labels

    cv2.imshow("Frame", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
