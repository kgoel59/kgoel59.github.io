import cv2

# Initialize the video capture object
cap = cv2.VideoCapture('carpark_f6_compressed.avi')

# Check if the video file opened successfully
if not cap.isOpened():
    print("Error: Couldn't open the video.")
    exit()

# Create the MOG2 background subtractor
bg_subtractor = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=50, detectShadows=True)

# Create a writer object to save the output video
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output_video.avi', fourcc, 20.0, (int(cap.get(3)), int(cap.get(4))))

while True:
    ret, frame = cap.read()

    if not ret:
        break

    # Apply the MOG2 background subtractor
    fg_mask = bg_subtractor.apply(frame)

    # Here, instead of removing the moving objects, we'll use the subtracted background directly
    # which doesn't contain any of the moving objects. The apply() method gives us this directly.
    bg_only = bg_subtractor.getBackgroundImage()

    # Write the frame to the output video
    out.write(bg_only)

    # Display the frame for visualization (optional)
    cv2.imshow('Background Only', bg_only)

    if cv2.waitKey(30) & 0xFF == ord('q'):
        break

cap.release()
out.release()
cv2.destroyAllWindows()
