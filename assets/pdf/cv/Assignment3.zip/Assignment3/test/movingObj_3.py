import cv2
import numpy as np

def detect_objects(frame, frame_count):
    fgbg = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=50, detectShadows=True)

    _ = fgbg.apply(frame)

    # Get the background for display
    bg = fgbg.getBackgroundImage()

    # Convert to grayscale for processing
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    

    # Detect moving pixels using Gaussian Mixture background modelling
    fgmask = fgbg.apply(gray, learningRate=-1)
    fgmask_raw = fgmask.copy()  # Before noise removal

    # Remove noise using morphological operators
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_CLOSE, kernel)
    fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)

    # Connected component analysis
    ret, labels = cv2.connectedComponents(fgmask)

    # Output buffer for detected objects
    detected = np.zeros_like(frame)

    # Classify each object and count them
    person_count, car_count, other_count = 0, 0, 0
    for label in range(1, ret):
        component = (labels == label).astype(np.uint8) * 255
        contours, _ = cv2.findContours(component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w) / h
            if 0.3 < aspect_ratio < 0.7:
                person_count += 1
            elif aspect_ratio > 1.5:
                car_count += 1
            else:
                other_count += 1
            detected[y:y+h, x:x+w] = frame[y:y+h, x:x+w]

    total_objects = person_count + car_count + other_count
    print(f"Frame {frame_count:04d}: {total_objects} objects ({person_count} persons, {car_count} cars and {other_count} others)")

    # Stack all frames for display
    # display_frame = np.vstack([
    #     np.hstack([frame, bg]),
    #     np.hstack([fgmask_raw, detected])
    # ])
    return bg

if __name__ == '__main__':
    cap = cv2.VideoCapture('carpark_f6_compressed.avi')
    width = int(cap.get(3))
    height = int(cap.get(4))
    scale = 640.0 / width
    cap.set(3, 640)
    cap.set(4, int(height * scale))

    frame_count = 0
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        frame_count += 1
        output_frame = detect_objects(frame, frame_count)
        cv2.imshow('Detection', output_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
