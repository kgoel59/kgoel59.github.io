'''7836685 kg956 CSCI935  Karan Goel Assignment 1'''


import sys
import cv2
import numpy as np

# Dictionary of available color spaces
CV_COLOR_SPACES = {
    "-XYZ": cv2.COLOR_BGR2XYZ,
    "-Lab": cv2.COLOR_BGR2LAB,
    "-YCrCb": cv2.COLOR_BGR2YCrCb,
    "-HSB": cv2.COLOR_BGR2HSV
}

def parseColorSpace(arg):
    """
    Take a string arg and check if arg in CV_COLOR_SPACES.
    If matches, return the corresponding cv2 color space.
    Else, return None.
    Exit the code and show a warning if the colorspace is not recognized.
    """
    if arg[0] != '-':
        return None

    if arg not in CV_COLOR_SPACES:
        print("Sorry, the color space you provided is not recognized by the program.")
        print("Please make sure the colorspace provided is one from the list:")
        for colorspace in CV_COLOR_SPACES:
            print(colorspace[1:])
        exit(0)
    return CV_COLOR_SPACES[arg]

def resize_image(img, width=640, height=360):
    """
    Resize the image while maintaining its aspect ratio.
    """
    aspect_ratio = img.shape[1] / img.shape[0]
    if aspect_ratio > 1:
        new_width = width
        new_height = int(new_width / aspect_ratio)
    else:
        new_height = height
        new_width = int(new_height * aspect_ratio)

    return cv2.resize(img, (new_width, new_height))

def pad_image_to_shape(img, target_height, target_width):
    #Auxilary function for grid display
    pad_height = target_height - img.shape[0]
    pad_width = target_width - img.shape[1]
    pad_spec = ((0, pad_height), (0, pad_width))
    if img.ndim == 3:  # if RGB or RGBA images
        pad_spec = pad_spec + ((0, 0),)
    return np.pad(img, pad_spec, mode='constant', constant_values=0)

def hstack_with_pad(image1, image2):
    #Auxilary function for grid display
    if image1.shape[0] == image2.shape[0]:
        return np.hstack((image1,image2))
    elif image1.shape[0] > image2.shape[0]:
        image2 = pad_image_to_shape(image2,image1.shape[0],image2.shape[1])
        return np.hstack((image1,image2))
    else:
        image1 = pad_image_to_shape(image1,image2.shape[0],image1.shape[1])
        return np.hstack((image1,image2))
    
def vstack_with_pad(image1, image2):
    #Auxilary function for grid display
    if image1.shape[1] == image2.shape[1]:
        return np.vstack((image1,image2))
    elif image1.shape[1] > image2.shape[1]:
        image2 = pad_image_to_shape(image2,image2.shape[0],image1.shape[1])
        return np.vstack((image1,image2))
    else:
        image1 = pad_image_to_shape(image1,image1.shape[0],image2.shape[1])
        return np.vstack((image1,image2))

def display_grid(title, images, window_size=(1280, 720)):
    """
    Display multiple images on a grid.
    """
    max_width = window_size[0] // 2
    max_height = window_size[1] // 2

    for id,image in enumerate(images):
        images[id] = resize_image(image, max_width, max_height)

    canvas = vstack_with_pad(
        hstack_with_pad(images[0],images[1]), 
        hstack_with_pad(images[2],images[3])
    )

    cv2.imshow(title, canvas)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def convertAndSplit(image, colorspace):
    """
    Convert the image to the provided color space and split into its channels.
    """
    converted = cv2.cvtColor(image, colorspace)
    ch1, ch2, ch3 = cv2.split(converted)
    return (
        cv2.cvtColor(ch1, cv2.COLOR_GRAY2BGR),
        cv2.cvtColor(ch2, cv2.COLOR_GRAY2BGR),
        cv2.cvtColor(ch3, cv2.COLOR_GRAY2BGR)
    )

def extract_foreground(green_screen_image, lower_range, upper_range):
    """
    Extract the foreground from a green-screen image.
    """
    green_screen_image = resize_image(green_screen_image.copy())
    hsv = cv2.cvtColor(green_screen_image, CV_COLOR_SPACES["-HSB"])
    mask = cv2.inRange(hsv, lower_range, upper_range)
    inv_mask = cv2.bitwise_not(mask)
    foreground = cv2.bitwise_and(green_screen_image, green_screen_image, mask=inv_mask)
    return inv_mask, foreground

def merge_with_background(foreground, mask, background):
    """
    Merge the extracted foreground with a given background.
    """
    background = resize_image(background.copy())
    offset_x = (background.shape[1] - mask.shape[1]) // 2
    offset_y = (background.shape[0] - mask.shape[0])

    # Pan (crop) the background
    background = background[:background.shape[0]-offset_y, offset_x:offset_x+foreground.shape[1]]

    for i in range(mask.shape[0]):
        for j in range(mask.shape[1]):
            if mask[i, j] == 255:
                background[i, j] = foreground[i, j]

    return background

def merge_with_white_background(foreground, mask):
    """
    Merge the extracted foreground with a white background.
    """
    white_background = 255 * np.ones_like(foreground)
    for i in range(white_background.shape[0]):
        for j in range(white_background.shape[1]):
            if mask[i, j] == 255:
                white_background[i, j] = foreground[i, j]
    return white_background

def main(arg1,arg2):
    """
    Main execution function.
    """
    colorspace = parseColorSpace(arg1)

    if colorspace:
        print("Running task1...")
        image = cv2.imread(arg2)
        ch1, ch2, ch3 = convertAndSplit(image, colorspace)
        if arg1 == "-HSB":
            #special case for hsb as per task1
            display_grid(f"Original and {arg1} Components",[image, ch3, ch1, ch2])
        else:
            display_grid(f"Original and {arg1} Components", [image, ch1, ch2, ch3])
    else:
        print("Running task2...")
        scenic_image, green_screen_image = cv2.imread(arg1), cv2.imread(arg2)
        mask, person_image = extract_foreground(green_screen_image, np.array([30, 90, 70]), np.array([80, 255, 255]))
        person_on_white = merge_with_white_background(person_image, mask)
        person_on_scenic = merge_with_background(person_image, mask, scenic_image)
        display_grid("Chromakey", [green_screen_image, person_on_white, scenic_image, person_on_scenic])

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Insufficient arguments provided. Please provide colorSpace and imageFile for task1, or scenicImageFile and greenScreenImageFile for task2.")
        exit(0)

    arg1, arg2 = sys.argv[1], sys.argv[2]


    main(arg1,arg2)
