'''7836685 Karan Goel Assignment 1'''

import sys
import cv2
import numpy as np

# ******************************************************************************#


# Exit the program if enough argument is not provided
if len(sys.argv) < 3:
    print("Enough args not provided.")
    exit(0)

# ******************************************************************************#

# Variables for Task 1
COLOR_SPACE = sys.argv[1]
IMAGE_FILE = sys.argv[2]
CV_COLOR_SPACES = {"-XYZ": cv2.COLOR_BGR2XYZ,
               "-Lab": cv2.COLOR_BGR2LAB,
               "-YCrCb": cv2.COLOR_BGR2YCrCb,
               "-HSB": cv2.COLOR_BGR2HSV}

# Variables for Task 2
IMAGE_FILE_SCENIC = sys.argv[1]
IMAGE_FILE_GREENSCREEN = sys.argv[2]

# ******************************************************************************#

# Task1
# Read the image
# Resize the image
# Convert the image into given color space
# Split the image into ch1,ch2,ch3
# Convert each channels into grayscale
# Stack the resized image and channel horizontaly and verticaly
# Display the stacked image
    

def task1():
    image = cv2.imread(IMAGE_FILE)
    image = cv2.resize(image, dsize=(640,360))
    converted = cv2.cvtColor(image,CV_COLOR_SPACES[COLOR_SPACE])
    ch1, ch2, ch3 = cv2.split(converted)

    # note : GRAY2BGR replicate single channel into three channel
    ch1 = cv2.cvtColor(ch1, cv2.COLOR_GRAY2BGR)
    ch2 = cv2.cvtColor(ch2, cv2.COLOR_GRAY2BGR)
    ch3 = cv2.cvtColor(ch3, cv2.COLOR_GRAY2BGR)


    combined = np.vstack((
        np.hstack((image, ch1)),
        np.hstack((ch2,ch3))
    ))

    cv2.imshow(f"Original and {COLOR_SPACE} Components", combined)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# ******************************************************************************#

def task2():
    
    print("Running Task 2.")

# ******************************************************************************#


# Main
if __name__ == "__main__":
    if COLOR_SPACE in CV_COLOR_SPACES:
        task1()
    else:
        task2()



