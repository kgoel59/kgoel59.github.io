import tkinter as tk
from tkinter import ttk

def on_value_change(val):
    # This function is called whenever the slider value changes
    label_var.set(f"Current value: {slider.get()}")

root = tk.Tk()
root.title("Slider Example")

# Create a slider
slider = ttk.Scale(root, from_=0, to=100, orient=tk.HORIZONTAL, command=on_value_change)
slider.pack(pady=20, padx=20)

# Label to display the current value
label_var = tk.StringVar()
label_var.set("Current value: 0")
label = ttk.Label(root, textvariable=label_var)
label.pack(pady=20)

root.mainloop()
