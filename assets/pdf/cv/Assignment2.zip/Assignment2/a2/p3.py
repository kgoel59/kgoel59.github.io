import cv2
import numpy as np
from sklearn.cluster import KMeans
import argparse
import os

def resize_image(image, target_height=480, target_width=600):
    h, w = image.shape[:2]
    aspect_ratio = w / h
    if h > w:
        new_height = target_height
        new_width = int(target_height * aspect_ratio)
    else:
        new_width = target_width
        new_height = int(target_width / aspect_ratio)
    return cv2.resize(image, (new_width, new_height))

def main(args):
    image_paths = args.images

    # Task One: Single Image
    if len(image_paths) == 1:
        image = cv2.imread(image_paths[0], cv2.IMREAD_COLOR)
        image_resized = resize_image(image)
        
        gray = cv2.cvtColor(image_resized, cv2.COLOR_BGR2GRAY)
        
        sift = cv2.SIFT_create()
        keypoints, descriptors = sift.detectAndCompute(gray, None)

        # Draw keypoints
        img_keypoints = cv2.drawKeypoints(image_resized, keypoints, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

        cv2.imshow('Original Image', image_resized)
        cv2.imshow('Keypoints', img_keypoints)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        # Task Two: Multiple Images
        all_descriptors = []
        image_descriptors = {}
        for path in image_paths:
            image = cv2.imread(path, cv2.IMREAD_COLOR)
            image_resized = resize_image(image)
            
            gray = cv2.cvtColor(image_resized, cv2.COLOR_BGR2GRAY)
            
            sift = cv2.SIFT_create()
            keypoints, descriptors = sift.detectAndCompute(gray, None)
            
            all_descriptors.extend(descriptors)
            image_descriptors[path] = descriptors

        # K-means clustering
        K = int(len(all_descriptors) * args.k_percent / 100)
        kmeans = KMeans(n_clusters=K)
        kmeans.fit(all_descriptors)

        # Construct histograms
        histograms = {}
        for path, descriptors in image_descriptors.items():
            hist = np.zeros(K)
            predictions = kmeans.predict(descriptors)
            for pred in predictions:
                hist[pred] += 1
            histograms[path] = hist / np.linalg.norm(hist)

        # Compare histograms
        for i, path1 in enumerate(image_paths):
            for j, path2 in enumerate(image_paths):
                if i >= j:
                    continue
                distance = np.linalg.norm(histograms[path1] - histograms[path2])
                print(f'Distance between {os.path.basename(path1)} and {os.path.basename(path2)}: {distance}')

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='SIFT keypoints extraction and comparison.')
    parser.add_argument('images', type=str, nargs='+', help='Paths to image files.')
    parser.add_argument('--k_percent', type=float, default=5, help='Percentage of total keypoints for K in K-means.')
    args = parser.parse_args()
    main(args)
