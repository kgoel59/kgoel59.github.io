'''7836685 kg956 CSCI935  Karan Goel Assignment 2'''
"""
Original file is located at
    https://colab.research.google.com/drive/1PGBJvjMxwTKOkZX2Q4L2eNMRMFfmAITR
"""

import sys
import os
import cv2
import numpy as np

"""Define a function to rescale an image to a size comparable to VGA size (480x600)"""

def rescale_image(image):
    # Get the original height and width of the image
    height, width = image.shape[:2]
    # Calculate the scaling factor based on the aspect ratio and the desired height
    scale = 480 / height
    # Resize the image using the scaling factor
    resized_image = cv2.resize(image, (int(width * scale), int(height * scale)))
    # Return the resized image
    return resized_image

"""Define a function to extract SIFT keypoints and descriptors from an image"""
def extract_sift(image):
    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Create a SIFT object
    sift = cv2.SIFT_create()
    # Detect and compute SIFT keypoints and descriptors
    keypoints, descriptors = sift.detectAndCompute(gray, None)
    # Return the keypoints and descriptors
    return keypoints, descriptors

"""Define a function to draw keypoints on an image"""
def draw_keypoints(image, keypoints):
    # Create a copy of the image
    img_keypoints = image.copy()
    # Draw a cross and a circle for each keypoint
    for k in keypoints:
      # Drawing the cross at the keypoint
      pt = (int(k.pt[0]), int(k.pt[1]))
      cv2.drawMarker(img_keypoints, pt, (0, 255, 0), markerType=cv2.MARKER_CROSS, markerSize=6, thickness=1)

      # Drawing the circle around the keypoint
      cv2.circle(img_keypoints, pt, int(k.size), (255, 0, 0), 1)

      # Drawing the line for orientation
      angle = k.angle * np.pi / 180  # Convert to radians
      length = k.size
      line_end = (int(pt[0] + length * np.cos(angle)), int(pt[1] + length * np.sin(angle)))
      cv2.line(img_keypoints, pt, line_end, (0, 0, 255), 1)
    # Return the image with keypoints
    return img_keypoints

"""Define a function to process args and extract image_names,images,keypoints_list,descriptors_list"""
def process_images(args):
    # Check if there is at least one input argument
    if len(args) > 0:
        # Initialize an empty list to store the image names
        image_names = []
        # Initialize an empty list to store the rescaled images
        images = []
        # Initialize an empty list to store the keypoints of each image
        keypoints_list = []
        # Initialize an empty list to store the descriptors of each image
        descriptors_list = []
        # Loop through each input argument
        for arg in args:
            # Try to read the image file
            image = cv2.imread(arg)
            # Check if the image is valid
            if image is not None:
                # Append the image name to the image names list
                image_name = os.path.basename(arg)
                image_names.append(os.path.basename(arg))

                # Rescale the image and append it to the images list
                rescaled_image = rescale_image(image)
                images.append(rescaled_image)

                # Extract SIFT keypoints and descriptors and append them to the corresponding lists
                keypoints, descriptors = extract_sift(rescaled_image)
                keypoints_list.append(keypoints)
                descriptors_list.append(descriptors)

                # Print nunber of keypoints
                print(f"# of keypoints in {image_name} is {len(keypoints)}")

            else:
                # Print an error message if the image is invalid
                print(f"Invalid image file: {arg}")

    return image_names,images,keypoints_list,descriptors_list

"""Define a function to cluster SIFT descriptors into K clusters using K-means algorithm"""
def cluster_sift(descriptors_list, K):
    # Concatenate all descriptors into a single array
    descriptors_array = np.concatenate(descriptors_list, axis=0)
    # Convert the array to float32 type
    descriptors_array = descriptors_array.astype(np.float32)
    # Define the criteria for K-means clustering (termination condition and number of iterations)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    # Perform K-means clustering on the descriptors array
    _, labels, centers = cv2.kmeans(descriptors_array, K, None, criteria, 20, cv2.KMEANS_RANDOM_CENTERS)
    # Return the labels and centers of the clusters
    return labels, centers

"""Define a function to construct a histogram of visual words for an image"""
def construct_histogram(descriptors, labels, K):
    # Initialize an empty histogram with K bins
    histogram = np.zeros(K)
    # Loop through each descriptor of the image
    for i in range(len(descriptors)):
        # Get the label of the cluster that the descriptor belongs to
        label = labels[i]
        # Increment the corresponding bin of the histogram by one
        histogram[label] += 1
    # Normalize the histogram by dividing each bin by the total number of descriptors
    histogram = histogram / len(descriptors)
    # Return the normalized histogram
    return histogram

"""Define a function to calculate the distance between two histograms using chi-square distance metric"""
def calculate_distance(histogram1, histogram2):
    # Calculate the chi-square distance between two histograms using numpy formula
    distance = np.sum((histogram1 - histogram2) ** 2 / (histogram1 + histogram2 + 1e-10))
    # Return the distance value
    return distance

"""Auxillary function to print matrix"""
def printmat(mat, labels):
  max_len = 0
  for i in range(0, len(labels)):
    labels[i] = labels[i].split('.')[0]
    max_len = max(max_len, len(labels[i]))
    space = max_len + 3
  # col labels
  for i in range(-1,len(labels)):
    if i == -1:
      print(' '*space,end='')
    else:
      print(f"{labels[i]:>{space}}",end='')
  print()
  for i in range(0,len(labels)):
      print(f"{labels[i]:>{space}}", end='')
      for j in range(0,len(labels)):
        print(f"{mat[i][j]:>{space}}",end='')
      print()

"""Define main function"""
def main(*args):
    """
    Main execution function.
    """

    image_names,images,keypoints_list,descriptors_list = process_images(args)

    if len(images) == 1:
      # Perform task one: draw keypoints on the image and display both images

      # Get the original and rescaled images
      original_image = images[0]
      rescaled_image = images[0]

      # Get the keypoints of the rescaled image
      keypoints = keypoints_list[0]

      # Draw keypoints on the rescaled image
      keypoints_image = draw_keypoints(rescaled_image, keypoints)

      # Display both images in a window
      cv2.imshow("Task 1", np.hstack((original_image,keypoints_image)))
      cv2.waitKey(0)
      cv2.destroyAllWindows()

    else:
      # Perform task two: compare each pair of images using a Bag-of-Words model

      #Set values of K for which matrix need to be generated (5%,10%,20%)
      ks = [0.05,0.1,0.2]
      for k in ks:
        #Calculate total key points
        total_keypoints = sum([len(keypoints) for keypoints in keypoints_list])

        print(f"K={100*k}%*({total_keypoints})={total_keypoints*k:.2f}")
        print("Dissimilarity Matrix")

        # Define the value of K as a percentage of the total number of keypoints
        K = int(k * sum([len(keypoints) for keypoints in keypoints_list]))

        # Cluster the SIFT descriptors into K clusters using K-means algorithm
        labels, centers = cluster_sift(descriptors_list, K)

        # Initialize an empty list to store the histograms of visual words for each image
        histograms = []

        # Initialize a variable to keep track of the starting index of each image's labels in the labels array
        start_index = 0

        # Loop through each image's descriptors and labels
        for i in range(len(images)):
          # Get the descriptors and labels of the current image
          descriptors = descriptors_list[i]
          end_index = start_index + len(descriptors)
          image_labels = labels[start_index:end_index]

          # Construct a histogram of visual words for the current image and append it to the histograms list
          histogram = construct_histogram(descriptors, image_labels, K)
          histograms.append(histogram)

          # Update the start index for the next image's labels
          start_index = end_index

        # Create a matrix to store distances
        matrix = np.empty((len(image_names), len(image_names)), dtype=object)
        matrix[:] = f"{0:.2f}"

        # Loop through each pair of images and calculate their distance using chi-square distance metric
        for i in range(len(images) - 1):
          for j in range(i, len(images)):
              # Get the histograms of visual words for the pair of images
              histogram1 = histograms[i]
              histogram2 = histograms[j]
              # Calculate the distance between the histograms
              distance = calculate_distance(histogram1, histogram2)
              # Save the distance value along with the pair of image names
              matrix[i,j] = f"{distance:.2f}"
              matrix[j,i] = f"{distance:.2f}"

        #Display Dissimilarity Matrix
        printmat(matrix,image_names)
        print()


# get args from user
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Insufficient arguments provided. Please provide image paths for task 1 and 2.")
        exit(0)

    main(*sys.argv[1:])