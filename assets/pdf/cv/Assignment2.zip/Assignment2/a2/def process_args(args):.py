def process_args(args):
    # Check if there is at least one input argument
    if len(args) > 0:
        # Initialize an empty list to store the image names
        image_names = []
        # Initialize an empty list to store the rescaled images
        images = []
        # Initialize an empty list to store the keypoints of each image
        keypoints_list = []
        # Initialize an empty list to store the descriptors of each image
        descriptors_list = []
        # Loop through each input argument
        for arg in args:
            # Try to read the image file
            image = cv2.imread(arg)
            # Check if the image is valid
            if image is not None:
                # Append the image name to the image names list
                image_names.append(arg)
                # Rescale the image and append it to the images list
                rescaled_image = rescale_image(image)
                images.append(rescaled_image)
                # Extract SIFT keypoints and descriptors and append them to the corresponding lists
                keypoints, descriptors = extract_sift(rescaled_image)
                keypoints_list.append(keypoints)
                descriptors_list.append(descriptors)
            else:
                # Print an error message if the image is invalid
                print(f"Invalid image file: {arg}")

    return image_names,images,keypoints_list,descriptors_list