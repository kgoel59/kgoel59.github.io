import cv2
import numpy as np
import sys

# Task One Function
def process_single_image(filename):
    # Load image
    img = cv2.imread(filename, cv2.IMREAD_COLOR)
    aspect_ratio = img.shape[1] / img.shape[0]

    # Rescale image to VGA size while preserving the aspect ratio
    new_width = int(480 * aspect_ratio)
    img_rescaled = cv2.resize(img, (new_width, 480))

    # Convert image to grayscale for SIFT processing
    gray = cv2.cvtColor(img_rescaled, cv2.COLOR_BGR2GRAY)

    # Extract SIFT keypoints
    sift = cv2.SIFT_create()
    keypoints, _ = sift.detectAndCompute(gray, None)

    # Draw keypoints
    img_keypoints = cv2.drawKeypoints(img_rescaled, keypoints, outImage=np.array([]), flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

    cv2.imshow("Original Image", img_rescaled)
    cv2.imshow("Keypoints Image", img_keypoints)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Task Two Function
def compare_images(filenames, k_percentage):
    images = []
    all_descriptors = []

    for filename in filenames:
        img = cv2.imread(filename, cv2.IMREAD_COLOR)
        aspect_ratio = img.shape[1] / img.shape[0]
        new_width = int(480 * aspect_ratio)
        img_rescaled = cv2.resize(img, (new_width, 480))
        gray = cv2.cvtColor(img_rescaled, cv2.COLOR_BGR2GRAY)

        sift = cv2.SIFT_create()
        keypoints, descriptors = sift.detectAndCompute(gray, None)
        images.append((img_rescaled, keypoints, descriptors))
        
        if descriptors is not None:
            all_descriptors.extend(descriptors)

    # Perform K-means clustering to get visual words
    k = int(k_percentage * len(all_descriptors))
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    _, labels, centers = cv2.kmeans(np.float32(all_descriptors), k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

    # Construct histograms of visual words for each image
    histograms = []
    for _, _, descriptors in images:
        histogram = np.zeros(k)
        if descriptors is not None:
            for i in range(descriptors.shape[0]):
                histogram[labels[i]] += 1
        histograms.append(histogram / np.linalg.norm(histogram))

    # Compare images using histograms
    for i in range(len(images)):
        for j in range(i+1, len(images)):
            distance = cv2.norm(histograms[i], histograms[j], cv2.NORM_L2)
            print(f"Distance between {filenames[i]} and {filenames[j]}: {distance}")

def main():
    args = sys.argv[1:]
    
    if len(args) == 1:
        process_single_image(args[0])
    elif len(args) > 1:
        # 0.2 implies K would be 20% of total keypoints.
        compare_images(args, 0.2)

if __name__ == "__main__":
    main()
