import cv2
import numpy as np

def rescale_image(image, target_size=(480, 600)):
  """Rescales an image to a given size while keeping the aspect ratio.

  Args:
    image: A numpy array representing the image.
    target_size: A tuple representing the target size of the image.

  Returns:
    A numpy array representing the rescaled image.
  """

  h, w = image.shape[:2]
  scale = min(target_size[0] / h, target_size[1] / w)
  new_h = int(h * scale)
  new_w = int(w * scale)
  resized_image = cv2.resize(image, (new_w, new_h))
  return resized_image

def draw_keypoints(image, keypoints):
  """Draws keypoints on an image.

  Args:
    image: A numpy array representing the image.
    keypoints: A list of keypoints.

  Returns:
    A numpy array representing the image with keypoints drawn on it.
  """

  for keypoint in keypoints:
    x, y = keypoint.pt
    size = keypoint.size
    angle = keypoint.angle

    # Draw a cross at the location of the keypoint.
    cv2.line(image, (x - size, y), (x + size, y), (255, 0, 0), 2)
    cv2.line(image, (x, y - size), (x, y + size), (255, 0, 0), 2)

    # Draw a circle around the keypoint whose radius is proportional to the scale of the keypoint.
    cv2.circle(image, (x, y), int(size * 1.5), (0, 255, 0), 2)

    # Draw a line from the cross to the circle indicating the orientation of the key point.
    end_x = x + size * np.cos(angle)
    end_y = y + size * np.sin(angle)
    cv2.line(image, (x, y), (int(end_x), int(end_y)), (0, 0, 255), 2)

  return image

def extract_sift_features(image):
  """Extracts SIFT features from an image.

  Args:
    image: A numpy array representing the image.

  Returns:
    A tuple of (keypoints, descriptors), where keypoints is a list of keypoints and descriptors is a
    numpy array of SIFT descriptors.
  """

  sift = cv2.xfeatures2d.SIFT_create()
  keypoints, descriptors = sift.detectAndCompute(image, None)
  return keypoints, descriptors

def cluster_sift_descriptors(descriptors, k):
  """Clusters SIFT descriptors using K-means clustering.

  Args:
    descriptors: A numpy array of SIFT descriptors.
    k: The number of clusters.

  Returns:
    A numpy array of cluster labels for each SIFT descriptor.
  """

  kmeans = cv2.kmeans(descriptors, k, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 0.1))
  labels = kmeans[1]
  return labels

def construct_histogram_of_visual_words(descriptors, labels):
  """Constructs a histogram of the occurrence of visual words from SIFT descriptors.

  Args:
    descriptors: A numpy array of SIFT descriptors.
    labels: A numpy array of cluster labels for each SIFT descriptor.

  Returns:
    A numpy array representing the histogram of the occurrence of visual words.
  """

  histogram = np.zeros(len(np.unique(labels)))
  for i in range(len(descriptors)):
        histogram[labels[i]] += 1
  return histogram

def calculate_distance_between_histograms(histogram1, histogram2):
  """Calculates the distance between two normalized histograms.

  Args:
    histogram1: A numpy array representing the first histogram.
    histogram2: A numpy array representing the second histogram.

  Returns:
    A float representing the distance between the two histograms.
  """

  histogram1 = histogram1 / np.sum(histogram1)
  histogram2 = histogram2 / np.sum(histogram2)
  distance = np.sum(np.abs(histogram1 - histogram2))
  return distance

def compare_images_using_sift(image1, image2, k=1000):
  """Compares two images using SIFT features and a Bag-of-Words model.

  Args:
    image1: A numpy array representing the first image.
    image2: A numpy array representing the second image.
    k: The number of clusters in the Bag-of-Words model.

  Returns:
    A float representing the distance between the two images.
  """

  # Rescale the images.
  image1_resized = rescale_image(image1)
  image2_resized = rescale_image(image2)

  # Extract SIFT features from the images.
  keypoints1, descriptors1 = extract_sift_features(image1_resized)
  keypoints2, descriptors2 = extract_sift_features(image2_resized)

  # Cluster the SIFT descriptors into visual words.
  labels1 = cluster_sift_descriptors(descriptors1, k)
  labels2 = cluster_sift_descriptors(descriptors2, k)

  # Construct histograms of the occurrence of visual words.
  histogram1 = construct_histogram_of_visual_words(descriptors1, labels1)
  histogram2 = construct_histogram_of_visual_words(descriptors2, labels2)

  # Calculate the distance between the histograms.
  distance = calculate_distance_between_histograms(histogram1, histogram2)

  return distance

if __name__ == "__main__":
  # Get the image paths from the command line arguments.
  image_paths = sys.argv[1:]

  # If there is only one image, detect keypoints and display the image with keypoints drawn on it.
  if len(image_paths) == 1:
    image = cv2.imread(image_paths[0])
    image_resized = rescale_image(image)
    keypoints, descriptors = extract_sift_features(image_resized)
    image_with_keypoints = draw_keypoints(image_resized, keypoints)

    cv2.imshow("Image with Keypoints", image_with_keypoints)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

  # If there are multiple images, compare each pair of images using SIFT features and a Bag-of-Words model.
  elif len(image_paths) > 1:
    print("Comparing images...")
    for i in range(len(image_paths) - 1):
      for j in range(i + 1, len(image_paths)):
        image1 = cv2.imread(image_paths[i])
        image2 = cv2.imread(image_paths[j])

        distance = compare_images_using_sift(image1, image2)

        print(f"Distance between {image_paths[i]} and {image_paths[j]}: {distance}")
  else:
    print("Usage: python compare_images_using_sift.py <image1.jpg> <image2.jpg> ...")
 
